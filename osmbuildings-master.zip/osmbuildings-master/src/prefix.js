(function(global) {

  'use strict';
